//
//  KLBarChartDataEntry.h
//  KLineDemo
//
//  Created by JoeXu on 2018/5/25.
//  Copyright © 2018年 KL. All rights reserved.
//

#import "KLChartDataEntry.h"

typedef NS_ENUM(NSUInteger,KLBarChartDataEntryType)
{
    KLBarChartDataEntryType_None,
    KLBarChartDataEntryType_Up,
    KLBarChartDataEntryType_Down,
};

@interface KLBarChartDataEntry : KLChartDataEntry

@property (nonatomic) KLBarChartDataEntryType barType;

@end
