//
//  KLBarChartDataSet.h
//  KLineDemo
//
//  Created by JoeXu on 2018/5/25.
//  Copyright © 2018年 KL. All rights reserved.
//

#import "KLChartDataSet.h"
#import <UIKit/UIColor.h>
#import "KLBarChartDataEntry.h"

@interface KLBarChartDataSet : KLChartDataSet

/// 颜色分别对应KLBarChartDataEntry 的三种状态
@property (nonatomic,strong) UIColor *color;
@property (nonatomic,strong) UIColor *upColor;
@property (nonatomic,strong) UIColor *downColor;


@property (nonatomic) CGFloat barWidth;//柱状图宽度

@end
