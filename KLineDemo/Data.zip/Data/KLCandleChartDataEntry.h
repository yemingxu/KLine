//
//  KLCandleChartDataEntry.h
//  KLineDemo
//
//  Created by JoeXu on 2018/5/25.
//  Copyright © 2018年 KL. All rights reserved.
//

#import "KLChartDataEntry.h"

@interface KLCandleChartDataEntry : KLChartDataEntry

@property (nonatomic,assign) CGFloat high;
@property (nonatomic,assign) CGFloat low;
@property (nonatomic,assign) CGFloat open;
@property (nonatomic,assign) CGFloat close;

@end
