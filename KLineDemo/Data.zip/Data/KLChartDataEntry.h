//
//  KLChartDataEntry.h
//  KLineDemo
//
//  Created by JoeXu on 2018/5/25.
//  Copyright © 2018年 KL. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreGraphics/CoreGraphics.h>

@interface KLChartDataEntry : NSObject

@property (nonatomic,assign) CGFloat x;

@property (nonatomic,assign) CGFloat y;

@property (nonatomic,strong) id data;

@end
