//
//  KLCandleChartDataSet.h
//  KLineDemo
//
//  Created by JoeXu on 2018/5/25.
//  Copyright © 2018年 KL. All rights reserved.
//

#import "KLChartDataEntry.h"
#import <UIKit/UIColor.h>
#import "KLCandleChartDataEntry.h"

@interface KLCandleChartDataSet : KLChartDataEntry

@property (nonatomic,strong) UIColor *upColor;
@property (nonatomic,strong) UIColor *downColor;

@property (nonatomic) CGFloat candleWidth;

@end
