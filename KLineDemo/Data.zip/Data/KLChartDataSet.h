//
//  KLChartDataSet.h
//  KLineDemo
//
//  Created by JoeXu on 2018/5/25.
//  Copyright © 2018年 KL. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreGraphics/CoreGraphics.h>
#import "KLChartDataEntry.h"

@protocol KLChartDataSet<NSObject>


- (void)notifyDataSetChanged;

- (void)calcMinMax;
- (void)calcMinMaxY:(CGFloat)fromX toX:(CGFloat)toX;

@property (nonatomic,readonly) CGFloat yMin;

@property (nonatomic,readonly) CGFloat yMax;

@property (nonatomic,readonly) CGFloat xMin;

@property (nonatomic,readonly) CGFloat xMax;

@property (nonatomic,readonly) int entryCount;


- (KLChartDataEntry *)entryForIndex:(int)i;
- (KLChartDataEntry *)entryForXValue:(CGFloat)xValue;

- (int)entryIndex:(KLChartDataEntry *)e;
- (int)entryIndexForXValue:(CGFloat)xValue;

- (BOOL)addEntry:(KLChartDataEntry *)e;
- (BOOL)removeEntry:(KLChartDataEntry *)e;
- (BOOL)removeEntryInIndex:(int)index;
- (BOOL)containsEntry:(KLChartDataEntry *)e;

@end

@interface KLChartDataSet : NSObject<KLChartDataSet>
{
    CGFloat _yMin;
    
    CGFloat _yMax;
    
    CGFloat _xMin;
    
    CGFloat _xMax;
    
    int _entryCount;
}

@property (nonatomic,strong) NSMutableArray<KLChartDataEntry *> *values;
- (instancetype)initWithValues:(NSMutableArray<KLChartDataEntry *> *)values;
- (instancetype)init NS_UNAVAILABLE;




- (void)calcMinMaxOnEntry:(KLChartDataEntry *)e;
- (void)calcMinMaxXOnEntry:(KLChartDataEntry *)e;
- (void)calcMinMaxYOnEntry:(KLChartDataEntry *)e;


@end

