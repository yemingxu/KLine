//
//  KLChartDataSet.m
//  KLineDemo
//
//  Created by JoeXu on 2018/5/25.
//  Copyright © 2018年 KL. All rights reserved.
//

#import "KLChartDataSet.h"

@implementation KLChartDataSet
@synthesize entryCount = _entryCount;
@synthesize yMin = _yMin;
@synthesize yMax = _yMax;
@synthesize xMax = _xMax;
@synthesize xMin = _xMin;
- (instancetype)initWithValues:(NSMutableArray<KLChartDataEntry *> *)values
{
    self = [super init];
    if (self){
        _values = [NSMutableArray arrayWithArray:values] ?: [NSMutableArray array];
    }
    return self;
}

- (void)notifyDataSetChanged
{
    [self calcMinMax];
}

- (void)calcMinMax
{
    if (_values.count == 0){ return; }
    
    _yMax = CGFLOAT_MIN;
    _yMin = CGFLOAT_MAX;
    _xMax = CGFLOAT_MIN;
    _xMin = CGFLOAT_MAX;
    
    for (KLChartDataEntry *e in _values){
        [self calcMinMaxOnEntry:e];
    }
}

- (void)calcMinMaxY:(CGFloat)fromX toX:(CGFloat)toX
{
    if (_values.count == 0){ return; }
    _yMax = CGFLOAT_MIN;
    _yMin = CGFLOAT_MAX;
    
    int indexFrom = [self entryIndexForXValue:fromX];
    int indexTo = [self entryIndexForXValue:toX];
    if (indexTo < indexFrom) { return ;}
    
    for (int i = indexFrom;i<=indexTo;i++) {
        // only recalculate y
        [self calcMinMaxYOnEntry:_values[i]];
    }
}

- (void)calcMinMaxOnEntry:(KLChartDataEntry *)e
{
    [self calcMinMaxXOnEntry:e];
    [self calcMinMaxYOnEntry:e];
}
- (void)calcMinMaxXOnEntry:(KLChartDataEntry *)e
{
    if (e.x < _xMin) {
        _xMin = e.x;
    }
    if (e.x > _xMax) {
        _xMax = e.x;
    }
}
- (void)calcMinMaxYOnEntry:(KLChartDataEntry *)e
{
    if (e.y < _yMin)  {
        _yMin = e.y;
    }
    if (e.y > _yMax) {
        _yMax = e.y;
    }
}


#pragma mark - --------- Values -------------

- (BOOL)addEntry:(KLChartDataEntry *)e
{
#warning 后期再 重新排序
    [_values addObject:e];
    return YES;
}
- (BOOL)removeEntry:(KLChartDataEntry *)e
{
    [_values removeObject:e];
    return YES;
}
- (BOOL)removeEntryInIndex:(int)index
{
    if (index >= 0 && index <= _values.count-1){
        [_values removeObjectAtIndex:index];
        return YES;
    }
    return NO;
}
- (BOOL)containsEntry:(KLChartDataEntry *)e
{
    return [_values containsObject:e];
}

- (KLChartDataEntry *)entryForIndex:(int)i
{
    if (i >= 0 && i <= _values.count-1){
        return _values[i];
    }
    return nil;
}
- (int)entryIndex:(KLChartDataEntry *)e
{
    if ([self containsEntry:e]){
        return (int)[_values indexOfObject:e];
    }
    return -1;
}

- (KLChartDataEntry *)entryForXValue:(CGFloat)xValue
{
    for (KLChartDataEntry *e in _values) {
        if (xValue >= e.x-0.5 && xValue <=e.x+0.5){
            return e;
        }
    }
    return nil;
}

- (int)entryIndexForXValue:(CGFloat)xValue
{
    KLChartDataEntry *e = [self entryForXValue:xValue];
    return e ? [self entryIndex:e] : -1;
}
@end
